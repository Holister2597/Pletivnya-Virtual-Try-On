/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { 
  Camera, 
  Upload, 
  Sparkles, 
  ChevronRight, 
  RefreshCcw, 
  ShoppingBag, 
  AlertCircle,
  Loader2,
  Check
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";

// --- Types & Constants ---

declare global {
  interface Window {
    aistudio?: {
      hasSelectedApiKey: () => Promise<boolean>;
      openSelectKey: () => Promise<void>;
    };
  }
}

interface Product {
  id: string;
  name: string;
  image: string;
  prompt: string;
}

const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Сіра плетена сумочка',
    image: 'https://lh3.googleusercontent.com/d/11XBjcZ9lzVec85SPHyP0tj6-SQMO6DDm',
    prompt: 'A stylish grey knitted handbag with a textured pattern and a shoulder strap.'
  },
  {
    id: '2',
    name: 'Лавандовий плед',
    image: 'https://lh3.googleusercontent.com/d/1DtQOu3ufZpG0IXqX1Lfu1iLKp_rXbWa1',
    prompt: 'A soft lavender knitted blanket (pled) with a cozy texture.'
  },
  {
    id: '3',
    name: 'Кардиган "Лавандові обійми"',
    image: 'https://lh3.googleusercontent.com/d/1QWORaqJIqeELutgv4f0Hrbm3rLN24PpV',
    prompt: 'A warm lavender knitted cardigan with a soft, comforting texture.'
  },
  {
    id: '4',
    name: 'Кардиган "Зефірніі Обійми"',
    image: 'https://lh3.googleusercontent.com/d/1DeZLG70aBAUEKeFG97rQUlHwMCxSVp-n',
    prompt: 'A light and fluffy white knitted cardigan, soft like a marshmallow.'
  }
];

const API_KEY = ""; // User will provide via environment or platform

// --- Helper Functions ---

const resizeImage = (base64Str: string, maxWidth = 1024, maxHeight = 1024): Promise<string> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = `data:image/jpeg;base64,${base64Str}`;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;

      if (width > height) {
        if (width > maxWidth) {
          height *= maxWidth / width;
          width = maxWidth;
        }
      } else {
        if (height > maxHeight) {
          width *= maxHeight / height;
          height = maxHeight;
        }
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL('image/jpeg', 0.8).split(',')[1]);
    };
  });
};

const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = async () => {
      const base64String = (reader.result as string).split(',')[1];
      const resized = await resizeImage(base64String);
      resolve(resized);
    };
    reader.onerror = (error) => reject(error);
  });
};

const imageUrlToBase64 = async (url: string): Promise<string> => {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Failed to fetch image: ${response.statusText}`);
  const blob = await response.blob();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(blob);
    reader.onload = async () => {
      const base64String = (reader.result as string).split(',')[1];
      const resized = await resizeImage(base64String);
      resolve(resized);
    };
    reader.onerror = (error) => reject(error);
  });
};

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// --- Components ---

export default function App() {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [userPhoto, setUserPhoto] = useState<string | null>(null);
  const [userPhotoAspectRatio, setUserPhotoAspectRatio] = useState<string>("1:1");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const calculateAspectRatio = (file: File): Promise<string> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const ratio = img.width / img.height;
        // Map to supported Gemini 2.5 aspect ratios: "1:1", "3:4", "4:3", "9:16", "16:9"
        if (ratio > 1.4) resolve("16:9");
        else if (ratio > 1.15) resolve("4:3");
        else if (ratio > 0.85) resolve("1:1");
        else if (ratio > 0.65) resolve("3:4");
        else resolve("9:16");
      };
      img.src = URL.createObjectURL(file);
    });
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const ratio = await calculateAspectRatio(file);
        setUserPhotoAspectRatio(ratio);
        const base64 = await fileToBase64(file);
        setUserPhoto(base64);
        setStep(2);
      } catch (err) {
        setError("Не вдалося завантажити фото. Спробуйте ще раз.");
      }
    }
  };

  const generateTryOn = async () => {
    if (!userPhoto || !selectedProduct) return;

    // Check for API key selection if using 3.1
    if (window.aistudio && !(await window.aistudio.hasSelectedApiKey())) {
      await window.aistudio.openSelectKey();
      // Proceeding after dialog - user might have selected or cancelled
    }

    setIsLoading(true);
    setError(null);
    setStep(3);

    const maxRetries = 3;
    let attempt = 0;

    while (attempt < maxRetries) {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || API_KEY });
        
        // Fetch product image as base64
        const productBase64 = await imageUrlToBase64(selectedProduct.image);

        const response = await ai.models.generateContent({
          model: "gemini-2.5-flash-image",
          contents: {
            parts: [
              {
                inlineData: {
                  mimeType: "image/jpeg",
                  data: userPhoto
                }
              },
              {
                inlineData: {
                  mimeType: "image/jpeg",
                  data: productBase64
                }
              },
              {
                text: `VIRTUAL TRY-ON & INTERIOR VISUALIZATION INSTRUCTIONS:
1. PRIMARY GOAL: Integrate the item from the SECOND image into the scene shown in the FIRST image.
2. SCENARIO HANDLING:
   - IF THE ITEM IS CLOTHING: Dress the person in it. It must fit naturally on their body.
   - IF THE ITEM IS A BAG/ACCESSORY: Place it naturally on the person (hanging from shoulder, held in hands, or cross-body).
   - IF THE ITEM IS A BLANKET/PLED:
     * If a person is the main subject: Wrap the blanket around the person to create a cozy, warm feeling.
     * If an interior/room is the main subject: Place the blanket naturally on furniture (sofa, bed, chair, or armchair) so it fits the room's decor and looks like a real part of the interior.
3. POSE & IDENTITY: 
   - STRICTLY PRESERVE the person's face, facial features, hair, and skin tone (if a person is present).
   - MAINTAIN the original background or interior structure exactly.
   - SUBTLE ADJUSTMENT: You MAY slightly adjust the position of the person's arms or hands ONLY to make the product placement (holding a bag, wrapping in a blanket) look realistic.
4. ITEM FIDELITY: The item MUST be a perfect visual replica of the one in the second image (color, knit pattern, texture).
5. ASPECT RATIO: The output image MUST match the aspect ratio of the first image (${userPhotoAspectRatio}).
6. OUTPUT: Generate only the final image.`
              }
            ]
          },
          config: {
            imageConfig: {
              aspectRatio: userPhotoAspectRatio as any
            }
          }
        });

        const imagePart = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
        if (imagePart?.inlineData?.data) {
          setGeneratedImage(`data:image/png;base64,${imagePart.inlineData.data}`);
          setStep(4);
          setIsLoading(false);
          return;
        } else {
          const textResponse = response.text;
          console.warn("No image in response. Model said:", textResponse);
          throw new Error(textResponse || "Модель не змогла згенерувати зображення. Спробуйте інше фото або виріб.");
        }
      } catch (err: any) {
        console.error("Generation error:", err);
        if (err.message?.includes("Requested entity was not found")) {
          // Reset key if it failed
          if (window.aistudio) await window.aistudio.openSelectKey();
        }
        
        attempt++;
        if (attempt >= maxRetries) {
          setError("Ой! Наша магія трохи втомилася. Спробуйте ще раз за мить.");
          setIsLoading(false);
          setStep(2);
        } else {
          await sleep(Math.pow(2, attempt) * 1000); // Exponential backoff
        }
      }
    }
  };

  const reset = () => {
    setStep(1);
    setUserPhoto(null);
    setSelectedProduct(null);
    setGeneratedImage(null);
    setError(null);
  };

  return (
    <div className="min-h-screen flex flex-col items-center py-8 px-4 sm:px-6">
      {/* Sticky Header */}
      <header className="sticky top-0 z-50 w-full max-w-[448px] bg-bg/80 backdrop-blur-md py-4 mb-8 flex flex-col items-center">
        <h1 className="playfair-italic text-3xl text-brand text-center">
          Примірочна Плетівні
        </h1>
        <p className="caveat text-brand/70 text-lg -mt-1">Віртуальна примірка наших виробів</p>
      </header>

      {/* Main Card Container */}
      <main className="w-full max-w-[448px] bg-white rounded-[2rem] shadow-xl shadow-brand/5 overflow-hidden border border-brand/5 flex flex-col">
        
        {/* Progress Tracker */}
        <div className="px-8 pt-8 pb-4">
          <div className="relative flex justify-between items-center">
            {/* Connecting Lines */}
            <div className="absolute top-1/2 left-0 w-full h-[1px] bg-brand/10 -translate-y-1/2 z-0" />
            <div 
              className="absolute top-1/2 left-0 h-[1px] bg-brand transition-all duration-500 -translate-y-1/2 z-0" 
              style={{ width: `${((step - 1) / 3) * 100}%` }}
            />
            
            {[1, 2, 3].map((s) => (
              <div 
                key={s}
                className={`relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all duration-300 ${
                  step >= s ? 'bg-brand text-white' : 'bg-white border border-brand/20 text-brand/40'
                }`}
              >
                {step > s ? <Check size={14} /> : s}
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-2 px-1">
            <span className={`text-[10px] uppercase tracking-widest ${step >= 1 ? 'text-brand font-bold' : 'text-brand/40'}`}>Фото</span>
            <span className={`text-[10px] uppercase tracking-widest ${step >= 2 ? 'text-brand font-bold' : 'text-brand/40'}`}>Виріб</span>
            <span className={`text-[10px] uppercase tracking-widest ${step >= 3 ? 'text-brand font-bold' : 'text-brand/40'}`}>Магія</span>
          </div>
        </div>

        {/* Error Message */}
        <AnimatePresence>
          {error && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="px-8 mb-4"
            >
              <div className="bg-red-50 border border-red-100 text-red-600 px-4 py-3 rounded-xl flex items-center gap-3 text-sm">
                <AlertCircle size={18} />
                <p>{error}</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Step Content */}
        <div className="flex-1 p-8">
          <AnimatePresence mode="wait">
            
            {/* Step 1: Upload */}
            {step === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="flex flex-col items-center text-center space-y-6"
              >
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full aspect-square rounded-3xl border-2 border-dashed border-brand/20 bg-brand/[0.02] hover:bg-brand/[0.05] transition-colors cursor-pointer flex flex-col items-center justify-center group"
                >
                  <div className="w-16 h-16 rounded-full bg-brand/10 flex items-center justify-center text-brand mb-4 group-hover:scale-110 transition-transform">
                    <Camera size={32} />
                  </div>
                  <h3 className="text-lg font-medium text-brand">Завантажте Ваше найкраще фото</h3>
                  <p className="text-sm text-brand/60 mt-2 px-8">
                    Найкраще підійде фото в повний зріст або по пояс на світлому фоні
                  </p>
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    onChange={handlePhotoUpload} 
                    accept="image/*" 
                    className="hidden" 
                  />
                </div>
                <p className="caveat text-xl text-brand/80">
                  "Ваша краса — наше натхнення..."
                </p>
              </motion.div>
            )}

            {/* Step 2: Selection */}
            {step === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="space-y-6"
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-medium text-brand">Що приміряємо?</h3>
                  <button 
                    onClick={() => setStep(1)}
                    className="text-xs text-brand/60 hover:text-brand flex items-center gap-1"
                  >
                    <RefreshCcw size={12} /> Змінити фото
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {PRODUCTS.map((product) => (
                    <div 
                      key={product.id}
                      onClick={() => setSelectedProduct(product)}
                      className={`relative rounded-2xl overflow-hidden cursor-pointer transition-all duration-300 ${
                        selectedProduct?.id === product.id 
                          ? 'ring-2 ring-brand ring-offset-2 scale-[1.02] shadow-lg shadow-brand/10' 
                          : 'hover:scale-[1.01] opacity-80 hover:opacity-100'
                      }`}
                    >
                      <img 
                        src={product.image} 
                        alt={product.name} 
                        className="w-full aspect-[3/4] object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black/60 to-transparent p-3">
                        <p className="text-white text-xs font-medium">{product.name}</p>
                      </div>
                      {selectedProduct?.id === product.id && (
                        <div className="absolute top-2 right-2 w-6 h-6 bg-brand text-white rounded-full flex items-center justify-center shadow-md">
                          <Check size={14} />
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                <button
                  disabled={!selectedProduct}
                  onClick={generateTryOn}
                  className={`w-full py-4 rounded-2xl flex items-center justify-center gap-2 font-medium transition-all ${
                    selectedProduct 
                      ? 'bg-brand text-white shadow-lg shadow-brand/20 hover:bg-brand/90' 
                      : 'bg-brand/10 text-brand/30 cursor-not-allowed'
                  }`}
                >
                  <Sparkles size={18} />
                  Приміряти магію
                </button>
              </motion.div>
            )}

            {/* Step 3: Generation (Loading) */}
            {step === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center justify-center py-12 space-y-8"
              >
                <div className="relative">
                  <motion.div 
                    animate={{ rotate: 360 }}
                    transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                    className="w-32 h-32 rounded-full border-2 border-dashed border-brand/20"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Loader2 className="animate-spin text-brand" size={48} />
                  </div>
                  <motion.div 
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="absolute -top-2 -right-2 text-brand"
                  >
                    <Sparkles size={24} />
                  </motion.div>
                </div>
                
                <div className="text-center space-y-2">
                  <h3 className="text-xl font-medium text-brand">Створюємо ваш образ</h3>
                  <p className="caveat text-2xl text-brand/70">
                    "Петелька до петельки, магія до магії..."
                  </p>
                </div>

                <div className="w-full bg-brand/5 rounded-full h-1 overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: '100%' }}
                    transition={{ duration: 15 }}
                    className="h-full bg-brand"
                  />
                </div>
              </motion.div>
            )}

            {/* Step 4: Result */}
            {step === 4 && generatedImage && (
              <motion.div
                key="step4"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="space-y-8"
              >
                <div className="relative p-4 bg-white rounded-3xl shadow-2xl shadow-brand/20 border border-brand/10">
                  <img 
                    src={generatedImage} 
                    alt="Результат примірки" 
                    className="w-full rounded-2xl"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute -bottom-4 -right-4 bg-brand text-white p-3 rounded-2xl shadow-lg">
                    <Sparkles size={20} />
                  </div>
                </div>

                <div className="space-y-3">
                  <button
                    onClick={() => window.open('https://www.instagram.com/pletivnya.ua/', '_blank')}
                    className="w-full py-4 bg-brand text-white rounded-2xl flex items-center justify-center gap-2 font-medium shadow-lg shadow-brand/20 hover:bg-brand/90 transition-all"
                  >
                    <ShoppingBag size={18} />
                    Замовити в Direct
                  </button>
                  <button
                    onClick={reset}
                    className="w-full py-4 bg-white text-brand border border-brand/20 rounded-2xl flex items-center justify-center gap-2 font-medium hover:bg-brand/5 transition-all"
                  >
                    <RefreshCcw size={18} />
                    Спробувати інше
                  </button>
                </div>

                <div className="text-center">
                  <p className="caveat text-xl text-brand/80">
                    "Ви виглядаєте неймовірно!"
                  </p>
                </div>
              </motion.div>
            )}

          </AnimatePresence>
        </div>

        {/* Footer Info */}
        <footer className="px-8 pb-8 text-center">
          <p className="text-[10px] text-brand/30 uppercase tracking-[0.2em]">
            © 2024 Плетівня • Handmade Luxury
          </p>
        </footer>
      </main>

      {/* Background Accents */}
      <div className="fixed top-0 left-0 w-full h-full pointer-events-none -z-10 overflow-hidden">
        <div className="absolute top-[-10%] right-[-10%] w-[40%] aspect-square rounded-full bg-brand/5 blur-[100px]" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[40%] aspect-square rounded-full bg-brand/5 blur-[100px]" />
      </div>
    </div>
  );
}
